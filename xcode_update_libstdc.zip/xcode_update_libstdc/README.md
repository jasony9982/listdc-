## libstdc-.6.0.9

将 install.sh 中的密码改为自己本地密码，运行即可
