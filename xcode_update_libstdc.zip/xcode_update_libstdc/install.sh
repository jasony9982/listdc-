#!/usr/bin/env bash
# 名称：Xcode11-libC++自动拷贝脚本
# 参数：参数1:mac密码

password=$1

# 校验参数
if [ ! -n "$password" ]; then
    read -t 10 -p "请输入password:" password
    stty echo
fi

if [ ! -n "$password" ]; then
    echo "密码不能为空"
    exit
fi
# 获取脚本执行目录
basepath=$(
    cd $(dirname $0)
    pwd
)
echo $password | sudo -S cp -R $basepath/iPhoneOS/* /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk/usr/lib/
echo $password | sudo -S cp -R $basepath/iPhoneSimulator/* /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/usr/lib/
echo $password | sudo -S cp -R $basepath/iPhoneSimulator/* /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Library/Developer/CoreSimulator/Profiles/Runtimes/iOS.simruntime/Contents/Resources/RuntimeRoot/usr/lib/
